package com.voiceclone.studio

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient()
    private var referenceUri by mutableStateOf<Uri?>(null)
    private var voiceId by mutableStateOf<String?>(null)
    private var status by mutableStateOf("अपनी आवाज़ की साफ़ रिकॉर्डिंग चुनें।")
    private var audioFile by mutableStateOf<File?>(null)
    private var consent by mutableStateOf(false)
    private var textValue by mutableStateOf("")
    private var language by mutableStateOf("Hindi")
    private var busy by mutableStateOf(false)
    private var player: MediaPlayer? = null

    private val saveAudio = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null && audioFile != null) {
            contentResolver.openOutputStream(uri)?.use { out -> audioFile!!.inputStream().use { it.copyTo(out) } }
            status = "WAV file save हो गई।"
        }
    }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            referenceUri = uri
            uploadReference(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    private fun base() = BuildConfig.VOICE_API_BASE_URL.trimEnd('/') + "/"

    private fun uploadReference(uri: Uri) {
        if (!consent) { status = "पहले consent checkbox चुनें।"; return }
        busy = true
        status = "Voice sample upload हो रहा है…"
        Thread {
            try {
                val temp = File(cacheDir, "voice_reference")
                contentResolver.openInputStream(uri)!!.use { input -> temp.outputStream().use { input.copyTo(it) } }
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("consent", "true")
                    .addFormDataPart("file", "reference_audio", temp.asRequestBody("application/octet-stream".toMediaType()))
                    .build()
                val req = Request.Builder().url(base() + "voice-reference").post(body).build()
                client.newCall(req).execute().use { res ->
                    val raw = res.body?.string().orEmpty()
                    if (!res.isSuccessful) throw Exception(raw)
                    voiceId = JSONObject(raw).optString("voice_id")
                    runOnUiThread { status = "Voice sample upload हो गया। Voice ID: $voiceId"; busy = false }
                }
            } catch (e: Exception) { runOnUiThread { status = "Upload error: ${e.message}"; busy = false } }
        }.start()
    }

    private fun generate() {
        if (!consent) { status = "अपनी आवाज़/अनुमति की पुष्टि करें।"; return }
        if (voiceId.isNullOrBlank()) { status = "पहले voice sample upload करें।"; return }
        if (textValue.isBlank()) { status = "पहले text लिखें।"; return }
        busy = true
        status = "Audio generate हो रहा है…"
        Thread {
            try {
                val lang = when(language) { "Hindi" -> "hi"; "Hinglish" -> "hinglish"; else -> "en" }
                val json = JSONObject().put("text", textValue).put("language", lang)
                    .put("voice_id", voiceId).put("consent", true).toString()
                val req = Request.Builder().url(base() + "generate")
                    .post(json.toRequestBody("application/json".toMediaType())).build()
                client.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) throw Exception(res.body?.string().orEmpty())
                    val bytes = res.body?.bytes() ?: throw Exception("Empty audio response")
                    val out = File(cacheDir, "voiceclone_output.wav")
                    out.writeBytes(bytes)
                    runOnUiThread { audioFile = out; status = "Audio तैयार है। Play दबाएँ।"; busy = false }
                }
            } catch (e: Exception) { runOnUiThread { status = "Generate error: ${e.message}"; busy = false } }
        }.start()
    }

    @Composable
    private fun Screen() {
        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("VOICECLONE", style = MaterialTheme.typography.headlineMedium)
                    Text("AI STUDIO  •  Hindi / Hinglish / English", style = MaterialTheme.typography.bodyMedium)
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("01  VOICE CLONE", style = MaterialTheme.typography.titleLarge)
                        Text("अपनी आवाज़ की 10–30 सेकंड की साफ़ रिकॉर्डिंग चुनें।")
                        Row { Checkbox(checked = consent, onCheckedChange = { consent = it }); Text("यह मेरी आवाज़ है या मेरे पास स्पष्ट अनुमति है।", Modifier.padding(top = 12.dp)) }
                        Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, enabled = !busy) { Text("Choose voice sample") }
                        Text(if (referenceUri == null) "No sample selected" else "Sample selected")
                    } }
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("02  TEXT TO SPEECH", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(value = textValue, onValueChange = { textValue = it }, label = { Text("अपनी स्क्रिप्ट यहाँ लिखें") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                        Text("Language")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Hindi", "Hinglish", "English").forEach { item ->
                                FilterChip(selected = language == item, onClick = { language = item }, label = { Text(item) })
                            }
                        }
                        Button(onClick = { generate() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Please wait…" else "Generate voice") }
                    } }
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("03  AUDIO OUTPUT", style = MaterialTheme.typography.titleLarge)
                        Text(status)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                audioFile?.let { file ->
                                    try { player?.release(); player = MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); start() } }
                                    catch (e: Exception) { status = "Playback error: ${e.message}" }
                                }
                            }, enabled = audioFile != null) { Text("Play") }
                            OutlinedButton(onClick = { saveAudio.launch("voiceclone_output.wav") }, enabled = audioFile != null) { Text("Save WAV") }
                        }
                    } }
                    Text("Backend URL: ${BuildConfig.VOICE_API_BASE_URL}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    override fun onDestroy() { player?.release(); super.onDestroy() }
}
