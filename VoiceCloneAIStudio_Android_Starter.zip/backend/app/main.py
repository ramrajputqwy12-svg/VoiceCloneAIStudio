from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from .engine import generate_audio

app = FastAPI(title="VoiceClone AI Studio API", version="0.1.0")
DATA = Path("data")
REFS = DATA / "references"
OUT = DATA / "outputs"
REFS.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
VOICE_STORE = {}

class GenerateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)
    language: str
    voice_id: str
    consent: bool

@app.get("/health")
def health():
    return {"ok": True, "service": "VoiceClone AI Studio", "engine_configured": False}

@app.post("/voice-reference")
async def voice_reference(file: UploadFile = File(...), consent: bool = Form(False)):
    if not consent:
        raise HTTPException(400, "Voice owner consent is required.")
    if not file.content_type or not (file.content_type.startswith("audio/") or file.filename.lower().endswith((".wav", ".mp3", ".m4a", ".ogg"))):
        raise HTTPException(415, "Upload an audio file.")
    data = await file.read()
    if len(data) > 20 * 1024 * 1024:
        raise HTTPException(413, "Audio must be under 20 MB.")
    voice_id = str(uuid4())
    path = REFS / f"{voice_id}_{Path(file.filename).name}"
    path.write_bytes(data)
    VOICE_STORE[voice_id] = str(path)
    return {"voice_id": voice_id, "message": "Reference saved. Configure an engine before generation."}

@app.post("/generate")
def generate(req: GenerateRequest):
    if not req.consent:
        raise HTTPException(400, "Voice owner consent is required.")
    if req.language not in {"hi", "hinglish", "en"}:
        raise HTTPException(400, "language must be hi, hinglish, or en")
    ref = VOICE_STORE.get(req.voice_id)
    if not ref:
        raise HTTPException(404, "Unknown voice_id. Upload the reference again.")
    try:
        output = generate_audio(text=req.text, language=req.language, reference_audio=ref, output_dir=OUT)
    except NotImplementedError as exc:
        raise HTTPException(501, str(exc))
    return FileResponse(output, media_type="audio/wav", filename="voiceclone_output.wav")
