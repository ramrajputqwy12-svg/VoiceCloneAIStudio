from pathlib import Path

def generate_audio(text: str, language: str, reference_audio: str, output_dir: Path) -> Path:
    """Connect a licensed, tested voice-cloning model here.

    Candidate research:
    - AI4Bharat IndicF5: Hindi and other Indic languages; review model access/license.
    - Chatterbox Multilingual V3: multilingual voice cloning; verify supported languages,
      hardware requirements, watermarking and model terms for your chosen checkpoint.
    - English can use a dedicated F5-TTS path if quality requires it.

    Do not assume Qwen3-TTS open weights support Hindi: the published open model list
    currently documents Chinese, English, Japanese, Korean, German, French, Russian,
    Portuguese, Spanish and Italian.

    Production adapter must:
    1. load reference audio and validate duration/sample rate;
    2. route hi / Hinglish / en to a tested model;
    3. normalize/chunk long text and concatenate safely;
    4. preserve any required watermark;
    5. write a WAV file and return its path.
    """
    raise NotImplementedError(
        "Voice model is not connected yet. Deploy a GPU backend and implement "
        "backend/app/engine.py with a model whose license and Hindi/Hinglish/English "
        "support have been verified."
    )
