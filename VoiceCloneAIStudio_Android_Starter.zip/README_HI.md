# VoiceClone AI Studio — Android starter

यह Android Studio starter project है: Kotlin + Jetpack Compose Android client और FastAPI cloud backend scaffold.

## क्या शामिल है
- Hindi / Hinglish / English text input
- Reference voice audio चुनना (WAV/MP3) और upload
- Generate request, status/error display, audio playback
- Generated WAV/MP3 को app cache में डाउनलोड करना
- Backend में consent confirmation अनिवार्य
- API base URL configurable (`local.properties` में `VOICE_API_BASE_URL`)

## जरूरी सच
यह **पूरा production voice-cloning service या APK नहीं** है। यह buildable client + backend integration scaffold है। Voice cloning के लिए GPU model runtime और hosting चाहिए। "Free online cloud server" की कोई स्थायी/गारंटीड मुफ्त GPU क्षमता नहीं होती; free tiers sleep/limits लगा सकते हैं। इस starter का backend `/generate` पर 501 देगा जब तक आप वैध model provider adapter जोड़कर deploy नहीं करते।

Qwen3-TTS के प्रकाशित open weights 10 भाषाओं में हैं और उसमें Hindi सूचीबद्ध नहीं है; इसलिए इस प्रोजेक्ट में उसे Hindi engine बताकर नहीं जोड़ा गया। Hindi/Hinglish के लिए IndicF5 / Chatterbox Multilingual V3 जैसे विकल्पों का अलग परीक्षण और उनके model/license terms की समीक्षा जरूरी है। अंग्रेज़ी के लिए भी चुने हुए engine की गुणवत्ता जाँचें।

## Android Studio में खोलना
1. ZIP extract करें।
2. Android Studio → **Open** → `android/` folder चुनें।
3. Gradle sync करें। JDK 17 रखें।
4. `android/local.properties.example` को `android/local.properties` नाम से copy करें और `VOICE_API_BASE_URL` को अपने HTTPS backend URL से बदलें।
5. Run दबाएँ।

## Backend चलाना (स्थानीय परीक्षण)
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Backend API docs: `http://localhost:8000/docs`

Android emulator से local backend के लिए `http://10.0.2.2:8000/` प्रयोग करें। असली फोन के लिए same Wi-Fi पर computer का LAN IP दें। Production में HTTPS लगाएँ।

## API contract
- `GET /health`
- `POST /voice-reference` multipart: `file`, `consent=true`
- `POST /generate` JSON: `text`, `language` (`hi`, `hinglish`, `en`), `voice_id`, `consent=true`
  - अभी model adapter configured न होने पर 501 लौटाता है।
  - Adapter जोड़ने के निर्देश `backend/app/engine.py` में हैं।

## सुरक्षा
केवल अपनी आवाज़ या स्पष्ट अनुमति वाली आवाज़ क्लोन करें। Reference audio निजी डेटा है; सार्वजनिक URL या खुले storage में न रखें। Production में authentication, rate limiting, file-size/type validation, deletion controls, encryption-at-rest, logging policy और model license compliance जोड़ें।
